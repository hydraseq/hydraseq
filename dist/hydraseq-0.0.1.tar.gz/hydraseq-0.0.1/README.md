# hydraseq
Simple data structure to remember sequences
